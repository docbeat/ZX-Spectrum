Lottery Numbers
===============

For the ZX Spectrum 48k
------------------------

A simple BASIC program that gets your Spectrum to pick your Lottery Numbers.

Includes routines for all 3 Games:

Lotto
Euro Millions
Set For Life

If you win big as a result of using this program then a donation will be appreciated :)